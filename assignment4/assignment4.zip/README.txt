Tony Zheng
101305951
Assignment 4

Files
    Makefile

    Header:
        defs.h
        Channel.h
        Media.h
        Search.h
        Array.h
        MediaTube.h
        MediaPlayer.h
        MediaFactory.h
        View.h
        Control.h
        TestControl.h
        Tester.h

    Source:
        Channel.cc
        Media.cc
        Search.cc
        MediaTube.cc
        MediaPlayer.cc
        MediaFactory.cc
        View.cc
        Control.cc
        TestControl.cc
        Tester.cc
        test.cc
        main.cc

Compilation and Execution
1. In the terminal, navigate to the assignment folder containing all of the files
2. Run the "make" command to compile and create an executable file called "a4"
3. Enter "./a4" to run the executable file