#include <iostream>
#include <fstream>
#include <string>
#include "Control.h"
#include "View.h"
#include <vector>


using namespace std;



int main(){
    Control control;
    control.launch();
    return 0;
}